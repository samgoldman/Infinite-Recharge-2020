#!/usr/bin/env python3

from robotpy_build.setup import setup

setup()
